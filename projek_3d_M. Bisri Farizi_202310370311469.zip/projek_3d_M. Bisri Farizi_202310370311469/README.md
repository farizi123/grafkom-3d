# 🤖 Robot Sederhana 3D - Proyek Visualisasi dengan Python + Pyodide

## 📌 Deskripsi Proyek
Proyek ini memvisualisasikan sebuah robot sederhana yang dibangun dari bentuk dasar 3D seperti bola, kubus, silinder, dan kerucut. Visualisasi dilakukan di browser menggunakan **Plotly** dan **Python melalui Pyodide**.

## 🧱 Komposisi Bentuk 3D
| Bagian        | Bentuk Dasar | Transformasi                     |
|---------------|---------------|----------------------------------|
| Kepala        | Bola          | Translasi ke atas, skala         |
| Badan         | Kubus         | Translasi, skala                 |
| Leher         | Silinder      | Translasi, skala                 |
| Tangan        | Kubus (balok) | Translasi ke samping, skala     |
| Antena        | Kerucut       | Translasi ke atas kepala         |

## 📁 Struktur Folder
```
projek_3d_nama_nim/
├── index.html        ← HTML utama, memuat Pyodide dan visualisasi
├── main.py           ← Script Python untuk model 3D
├── README.md         ← Penjelasan proyek
```

## ▶️ Cara Menjalankan di itch.io
1. Masuk ke akun itch.io dan buat project baru.
2. Pilih **"HTML"** sebagai jenis project.
3. Upload seluruh isi folder (`index.html`, `main.py`, dan `README.md`).
4. Simpan dan buka halaman itch.io untuk melihat hasilnya.

## 💻 Teknologi
- Python 3 melalui Pyodide
- Plotly (graph_objects)
- HTML/CSS ringan

## 🎯 Tujuan Pembelajaran
- Menerapkan representasi objek 3D menggunakan bentuk dasar.
- Menggunakan transformasi geometri (translasi, rotasi, skala).
- Menyusun scene graph sederhana untuk komposisi objek.
- Mengintegrasikan Python dengan teknologi web.

---

📬 Untuk pertanyaan lebih lanjut, silakan hubungi dosen atau asisten praktikum.

> Dibuat oleh: [Nama Anda] - [NIM Anda]
