import plotly.graph_objects as go
import numpy as np

# Fungsi primitif dasar 3D
def create_sphere(center, radius, color):
    u, v = np.mgrid[0:2*np.pi:20j, 0:np.pi:10j]
    x = center[0] + radius * np.cos(u) * np.sin(v)
    y = center[1] + radius * np.sin(u) * np.sin(v)
    z = center[2] + radius * np.cos(v)
    return go.Surface(x=x, y=y, z=z, colorscale=[[0, color], [1, color]], showscale=False)

def create_cube(center, size, color):
    # Cube terdiri dari 6 sisi (mesh)
    x0, y0, z0 = center
    s = size / 2
    vertices = np.array([
        [x0 - s, y0 - s, z0 - s], [x0 + s, y0 - s, z0 - s],
        [x0 + s, y0 + s, z0 - s], [x0 - s, y0 + s, z0 - s],
        [x0 - s, y0 - s, z0 + s], [x0 + s, y0 - s, z0 + s],
        [x0 + s, y0 + s, z0 + s], [x0 - s, y0 + s, z0 + s]
    ])
    I = [0, 0, 0, 1, 1, 2, 3, 4, 5, 6, 7, 7]
    J = [1, 3, 4, 2, 5, 3, 7, 5, 6, 7, 4, 6]
    K = [2, 2, 5, 3, 6, 7, 6, 6, 7, 6, 5, 5]
    x, y, z = vertices[:, 0], vertices[:, 1], vertices[:, 2]
    return go.Mesh3d(x=x, y=y, z=z, i=I, j=J, k=K, color=color, opacity=1)

def create_cylinder(center, radius, height, axis='z', color='blue'):
    theta = np.linspace(0, 2*np.pi, 30)
    z = np.linspace(0, height, 10)
    theta, z = np.meshgrid(theta, z)
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    if axis == 'z':
        x, y, z = x + center[0], y + center[1], z + center[2]
    return go.Surface(x=x, y=y, z=z, colorscale=[[0, color], [1, color]], showscale=False)

def create_cone(center, radius, height, direction='z', color='red'):
    theta = np.linspace(0, 2*np.pi, 30)
    r = np.linspace(0, radius, 10)
    r, theta = np.meshgrid(r, theta)
    x = r * np.cos(theta)
    y = r * np.sin(theta)
    z = height * (1 - r / radius)
    if direction == 'z':
        x, y, z = x + center[0], y + center[1], z + center[2]
    return go.Surface(x=x, y=y, z=z, colorscale=[[0, color], [1, color]], showscale=False)

# Objek 3D: Robot Sederhana
fig = go.Figure()

# Kepala (sphere)
fig.add_trace(create_sphere(center=[0, 0, 6], radius=1, color='orange'))

# Badan (cube)
fig.add_trace(create_cube(center=[0, 0, 3], size=2.5, color='blue'))

# Leher (cylinder)
fig.add_trace(create_cylinder(center=[0, 0, 4.5], radius=0.3, height=0.5, color='gray'))

# Tangan kiri dan kanan (cube panjang)
fig.add_trace(create_cube(center=[-2, 0, 3], size=1, color='green'))
fig.add_trace(create_cube(center=[2, 0, 3], size=1, color='green'))

# Antena (cone)
fig.add_trace(create_cone(center=[0, 0, 7.5], radius=0.2, height=1, color='red'))

# Set tata letak kamera
fig.update_layout(
    scene=dict(
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
        zaxis=dict(visible=False),
        aspectratio=dict(x=1, y=1, z=1),
    ),
    margin=dict(l=0, r=0, b=0, t=0)
)

fig.show()
